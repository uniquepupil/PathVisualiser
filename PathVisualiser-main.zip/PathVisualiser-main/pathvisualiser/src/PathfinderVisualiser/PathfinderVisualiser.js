import React, { Component } from "react";
import Grid from "./components/Grid";

export default class PathfinderVisualiser extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  render() {
    return <Grid></Grid>;
  }
}
